#!/opt/local/bin/python3

# NAAM: 	Devin Hillenius
# CKNUM:	11018070
# STUDIE: 	Informatica

# This sudoku solver will solve a sudoku. This sudoku has to be in a textfile which name has to be
# given as argument when starting this program. (e.g. 'python sudoku.py sudoku.txt') This sudoku
# should only consist of numbers and whitespace in between them (forming a grid) all free spots
# should be represented as a '0'. This program solves the sudoku using an algorithm that performs
# an exhaustive search through potential solution of the sudoku (using a
# search tree).
import sys
import os
from math import sqrt

# Global variables needed for the algorithm.
sudoku_rows = []
sudoku_columns = []
sudoku_blocks = []
sudoku_size = 0
search_tree = []
log = []


def main():
    """In this main function, the whole program will be started. It will start of by reading and
    checking a sudoku from a file (which name has to be given as argument). After that it will
    start assigning values to the global variables for use in the program. Ultimately it will
    check if the sudoku is has a possible solution and if so it will solve the sudoku."""
    if read_and_check_sudoku_from_file():
        # The sudoku is OK, the variables can be assigned!
        global sudoku_size, sudoku_blocks, sudoku_columns
        sudoku_size = len(sudoku_rows)
        sudoku_blocks = create_block_list()
        sudoku_columns = create_column_list()
        # Check if the sudoku actually has a possible solution. If so: solve
        # the sudoku!
        if sudoku_possible():
            print("Sudoku is possible, looking for a solution...")
            print()
            solve_sudoku()
        else:
            print("Sudoku is not possible, please try again.")
    print()


def read_and_check_sudoku_from_file():
    """This function will read a sudoku from a file and afterwards check if the sudoku is valid.
    It will check to see if the size of the sudoku is a square integer, if the sudoku is a perfect
    square and to see if there's no illegal numbers or characters in the sudoku. It will also
    check if the given file really exists. If something isn't right, it will print a helpful
    message.

    Returns:
            True if there's nothing wrong with the sudoku / file or False if there is."""
    # Check if the given file exists.
    if (os.path.isfile(sys.argv[1])):
        # The file exists, create a sudoku grid from it.
        with open(sys.argv[1]) as grid:
            # Try the following list comprehension, if there's an error in casting to an int there
            # has to be an illegal character in the sudoku.
            try:
                grid_list = [[int(num) for num in row.split()] for row in grid]
            except BaseException:
                print("There's an illegal character in the sudoku, try again!")
                return False

        # Check if the size of the sudoku is a square integer.
        if (sqrt(len(grid_list)) - int(sqrt(
                len(grid_list)))) <= sys.float_info.epsilon:
            # Check if the sudoku is a square.
            if is_square(grid_list):
                # Check if there are no illegal numbers in the sudoku.
                if no_illegal_nums(grid_list):
                    # Sudoku is OK, save it as a global variable and return
                    # True.
                    global sudoku_rows
                    sudoku_rows = grid_list
                    return True
                else:
                    print(
                        "There's an illegal number in the sudoku, try again!")
            else:
                print("The sudoku has to be a square, try again!")
        else:
            print(
                "The size of the sudoku has to be a square number, try again!")
    else:
        print("This file does not exist, try again!")

    return False


def create_column_list():
    """This function will create a list of lists containing the columns of the sudoku. These will
    be sorted from left to right.

    Returns:
            A list of lists containing all the columns of the sudoku."""
    row_list = [[int(sudoku_rows[row][col]) for row in range(sudoku_size)]
                for col in range(sudoku_size)]

    return row_list


def create_block_list():
    """This function will create a list of lists of the blocks in the sudoku. These will be
    sorted from top to bottom starting with the topleft block.

    Returns:
            A list of lists containing all blocks in the sudoku."""
    # The width/ height of a block is the square root of the width/ height of
    # the full sudoku grid.
    block_size = int(sqrt(sudoku_size))

    # The following nested list comprehension builds the list of lists of the
    # blocks in the sudoku.
    block_list = [[
        int(sudoku_rows[block_size * y + block_y][block_size * x + block_x])
        for block_y in range(block_size) for block_x in range(block_size)
    ] for x in range(block_size) for y in range(block_size)]
    return block_list


def sudoku_possible():
    """This function will check whether a given sudoku (that's already defined as sudoku_rows,
    sudoku_columns and sudoku_blocks) has a possibile solution. It has one if there are no
    duplicate numbers in any row, column or block.

    Returns:
            True if a sudoku has a possible solution and False if that's not the case."""
    return all_unique(sudoku_rows) and all_unique(
        sudoku_columns) and all_unique(sudoku_blocks)


def solve_sudoku():
    """This function will solve a given sudoku. This is done by finding all possibilities for the
    first empty spot and keep trying for all upcoming free spots. It will keep track of a log in
    which all changed positions in the grid are listed, if there are no possibilities for the next
    free spot it will have to backtrack and therefore look up the changes in the log. On top of
    that, it will keep track of all possibilities (that are used) in a search tree. Since the log
    and the search tree are constantly being edited, ultimately the log list will contain just all
    original free spots and in the search tree all the leftmost elements in the lists will be the
    used numbers for these free spots."""
    global log, search_tree

    while True:
        # Check if the sudoku is still has free spots left or not.
        if next_free_spot() is not 0:
            # There's still a free spot left, try to find possibilities for it.
            row, col = next_free_spot()
            possibilities = get_possibilities(row, col)
            # Check whether there are possibilities.
            if possibilities:
                # Update the log and the search tree.
                search_tree.append(possibilities)
                log.append((row, col))
                # Try the leftmost possibility.
                fill_spot(possibilities[0], row, col)

            else:
                # Reverse the last steps. The last done possibility is no longer a possibility and
                # should therefore be removed from the search tree.
                remove_from_search_tree()
                # Make sure a new possibility is added in the sudoku grid so after this new
                # possibilities can be found.
                update_sudoku_grid()
        else:
            # The sudoku is completed! Print the sudoku and break out of the
            # loop.
            print("Found a solution!")
            for line in sudoku_rows:
                print(*line)
            break


def next_free_spot():
    """This function will find the next free spot in the sudoku grid (this is a spot in the sudoku
    with the number zero in it). If there is none, it will return 0. If there is a free spot,
    it will return the row and column of that free spot.

    Returns:
            Either 0 if the sudoku is complete or the row and column numbers of the free spot if
            one is found."""
    for row in range(sudoku_size):
        for col in range(sudoku_size):
            if sudoku_rows[row][col] is 0:

                # A free spot is found, return the row and column numbers.
                return row, col

    # No free spots are found, the sudoku is completely filled in.
    return 0


def get_possibilities(row, col):
    """This function will find all possibilities for a given spot in the sudoku. This obeys the
    sudoku rules, which means that the possibility should not be in the same row, column or block
    as the given (free) spot.

    Args:
            The row number (starting from zero).
            The column number (starting from zero).

    Returns:
            A list containing the possibilities for the given spot in the sudoku."""
    return [
        num for num in gen_missing_nums(sudoku_rows[row])
        if num in gen_missing_nums(sudoku_columns[col])
        and num in gen_missing_nums(sudoku_blocks[get_block(row, col)[0]])
    ]


def fill_spot(num, row, col):
    """This function will fill a given position in the sudoku with a given number. Since we work
    with lists containing the rows, columns and blocks it will add the number to all those lists
    in the given place.

    Args:
            num: The number that has to be placed in the given spot.
            row: The row number of the position the number has to be placed in.
            col: The column number of the position the number has to be placed in."""
    global sudoku_rows, sudoku_columns, sudoku_blocks
    sudoku_rows[row][col] = num
    sudoku_columns[col][row] = num
    sudoku_blocks[get_block(row, col)[0]][get_block(row, col)[1]] = num


def step_backwards():
    """This function will reverse the last step by removing the last placed number on the sudoku
    grid. It will also update the log by removing the last entry."""
    global log
    fill_spot(0, *log[-1])
    log.pop()


def remove_from_search_tree():
    """This function will remove all impossible 'possibilities' from the search tree. Since this
    function will only be called when the most left number of the last element is wrong, it will
    remove all 'possibilities' alone in lists right above the bottom one."""
    # Remove the last used 'possibility' from the search tree. This is either the first element in
    # the last list (if the last list is more than 1 long) or it is the last list in total if
    # there's only one element in it.
    global search_tree

    if len(search_tree[-1]) is 1:
        # The last list with possibilities in the search tree has a length of 1. Therefore this
        # element and all single possibilities before will have to be removed.
        search_tree.pop()
        step_backwards()
        while len(search_tree[-1]) is 1:
            step_backwards()
            search_tree.pop()
        # All single possibilities in the list are removed, now the leftmost element of the last
        # list of possibilities with more than one possibility has to be
        # removed.
        search_tree[-1].pop(0)
    else:
        # The last list of the list with lists with possibilities has a length of more than one,
        # therefore only the leftmost element of this list should be removed.
        search_tree[-1].pop(0)


def update_sudoku_grid():
    """This function will update the sudoku grid after possibilities were removed from the search
    tree. It will fill the sudoku grid with the new possibility on the last cleared spot so it can
    continue to look for new possibilities."""
    fill_spot(search_tree[-1][0], *log[-1])


def all_unique(input_list):
    """This function will check whether a list in a list of lists (with columns, rows or blocks
    from the sudoku) contains all unique elements in it. Because free spots in the sudoku are
    represented as zeroes, these will not be taking into consideration when finding out if the
    list contains no duplicate elements.

    Args:
            input_list: The list of lists (from the sudoku) which has to be checked.

    Returns:
            True if for all lists in the list of lists all the elements are unique. Otherwise False is
            returned."""
    for segment in input_list:
        segnment_no_zero = [num for num in segment if num is not 0]
        if len(segnment_no_zero) is not len(set(segnment_no_zero)):
            return False
    return True


def is_square(input_list):
    """This function will check to see if a given list of lists is a square. That is when the
    length of the total list is the same as the length of every individual list in the list of
    lists.

    Args:
            input_list: A list of lists to check.

    Returns:
            True if the list of lists is a square and False otherwise."""
    size = len(input_list)
    for row in input_list:
        if len(row) is not size:
            return False
    return True


def no_illegal_nums(input_list):
    """This function will check if there's no illegal numbers in a given list of lists (that
    represents a sudoku grid). Illegal numbers are numbers that are not in the range 0
    (representing a free spot) to n (the size of the sudoku).

    Args:
            input_list: A list of lists to check.

    Returns:
            True if there are no illegal numbers found and False otherwise."""
    sudoku_range = range(len(input_list) + 1)
    for row in input_list:
        row_no_illegal_chars = [num for num in row if num in sudoku_range]
        if len(row_no_illegal_chars) is not len(input_list):
            return False
    return True


def gen_missing_nums(input_list):
    """This function will return all missing integers in a list of n integers long that has to
    contain all integers from 1 to n.

    Args:
            input_list: A list for which missing numbers should be generated.

    Returns:
            All the integers that are not in the given (n integers long) list but should be there to
            make the list contain all integers from 1 to n."""
    # A generator that will generate all integers in the range 1 to n not already included in the
    # given list.
    return [
        num for num in range(1,
                             len(input_list) + 1) if num not in input_list
    ]


def get_block(row, col):
    """This function will find in which specific block an element of the sudoku is located given
    the row and column index and the list of blocks. It will afterwards return the block number
    and the position of the element in the block list itself.

    Args:
            row: The row number the element is in, starting from 0.
            col: The column number the element is in, starting from 0.

    Returns:
            A tuple containing the number the needed block has in the list of blocks. And also
            containing the position of the needed block element in the block list."""
    # Find out what the block width/ height is from the given list.
    block_size = int(sqrt(sudoku_size))

    # Find out the block number (starting from 0 for the top left block).
    block_num = int(int(col / block_size) * block_size + int(row / block_size))
    pos_in_block = int((col % block_size) * block_size + (row % block_size))
    return block_num, pos_in_block


if __name__ == "__main__":
    main()
