#!/opt/local/bin/python3

# NAAM: 	Devin Hillenius
# CKNUM:	11018070
# STUDIE: 	Informatica

from math import sqrt

def test():
	"""This function is used only to easily test the multiple functions in this python program."""
	print("Exercise 1:")
	read_file()

	print()
	print("Exercise 2:")
	print(test_integer_list([1, 2, 3, 4, 5]))
	print(test_integer_list([1, 2, 0, 4, 5]))

	print()
	print("Exercise 3:")
	print(generate_missing_integers([1, 0, 3, 4, 5, 6]))
	print(generate_missing_integers([1, 0, 3, 4, 0, 6]))

	print()
	print("Exercise 4a:")
	get_blocks()

	print()
	print("Exercise 4b:")
	get_block(1, 1, [[3, 9, 6, 1, 7, 8, 5, 2, 4], [9, 1, 5, 4, 8, 3, 2, 6, 7], 
					[6, 5, 2, 7, 4, 9, 8, 3, 1], [8, 5, 1, 2, 9, 4, 6, 7, 3], 
					[4, 8, 7, 9, 2, 6, 3, 1, 5], [1, 3, 8, 5, 6, 2, 7, 4, 9], 
					[7, 4, 2, 3, 5, 6, 8, 9, 1], [2, 6, 3, 5, 1, 7, 9, 8, 4], 
					[4, 7, 9, 1, 3, 8, 6, 2, 5]])
	get_block(5, 8, [[3, 9, 6, 1, 7, 8, 5, 2, 4], [9, 1, 5, 4, 8, 3, 2, 6, 7], 
					[6, 5, 2, 7, 4, 9, 8, 3, 1], [8, 5, 1, 2, 9, 4, 6, 7, 3], 
					[4, 8, 7, 9, 2, 6, 3, 1, 5], [1, 3, 8, 5, 6, 2, 7, 4, 9], 
					[7, 4, 2, 3, 5, 6, 8, 9, 1], [2, 6, 3, 5, 1, 7, 9, 8, 4], 
					[4, 7, 9, 1, 3, 8, 6, 2, 5]])

def read_file():
	"""Using this function, a textfile containing a sudoku grid (containing only numbers and
	spaces in between them) will be read and converted into a list of lists containing the rows. 

	Afterwards this list of lists is printed exactly like the input file with only the numbers and
	white spaces in between them.

	Returns:
		A list of lists containing all the rows of the sudoku grid in the input file. (this return
		should be ignored for this exercise because it's solely used for exercise 4)"""
	# Create a list of lists from the sudoku grid in the textfile called 'file'.
	with open("file.txt") as grid:
		read_list = [[int(num) for num in row.split()] for row in grid]

	# Print the list exactly like it was in the input file.
	for line in read_list:
		print(*line)

	# Returns the list so this function can also be used in exercise 4.
	return read_list

def test_integer_list(input_list):
	"""This function will return whether a list of n integers long contains all integers from 
	1 to n.

	Args:
		input_list: A list containing integers that should be checked in this function.

	Returns:
		True or False depending on whether the given list of n integers contains all the integers 
		from 1 to n."""
	for num in range(1, len(input_list) + 1):
		if num not in input_list:
			return False
	return True

def generate_missing_integers(input_list):
	"""This function will return all missing integers in a list of n integers long that has to 
	contain all integers from 1 to n. 

	Args:
		input_list: A list containing integers that should be 'filled' in this function.

	Returns:
		All the integers that are not in the given (n integers long)list but should be there to 
		make the list contain all integers from 1 to n."""
	# A generator that will generate all integers in the range 1 to n not already included in the 
	# given list.
	return [num for num in range(1, len(input_list) + 1) 
			if num not in input_list]

def get_blocks():
	"""This function will create a list of lists of the blocks in the sudoku. This sudoku is 
	gotten read from a textfile in the read_file function. 

	The created list containing the blocks of the sudoku will be printed afterwards. These will be 
	sorted from top to bottom starting with the topleft block."""
	sudoku_grid = read_file()

	# The width/ height of a block is the square root of the width/ height of the full sudoku grid.
	block_size = int(sqrt(len(sudoku_grid)))

	# The following nested list comprehension builds the list of lists of the blocks in the sudoku.
	block_list = [[int(sudoku_grid[block_size * y + block_y][block_size * x + block_x])
				  for block_y in range(block_size) for block_x in range(block_size)]
				  for x in range(block_size) for y in range(block_size)]
	print(block_list)

def get_block(row, col, blocks):
	"""This function will find in which specific block an element of the sudoku is located given 
	the row and column index and the list of blocks. It will afterwards print the specific block 
	containing the element.

	Args:
		row: The row number the element is in, starting from 1.
		col: The column number the element is in, starting from 1.
		blocks: A list of lists containing the blocks of the sudoku."""
	# Find out what the block width/ height is from the given list.
	block_size = int(sqrt(len(blocks[0])))

	# Find out the block number (starting from 0 for the top left block).
	block_num = int((col - 1)/block_size) * block_size + int((row - 1)/block_size)
	print(blocks[block_num])

if __name__ == "__main__":
	test()