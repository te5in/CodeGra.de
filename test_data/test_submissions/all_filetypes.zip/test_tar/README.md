# CodeGra.tests
This repository contain the manuals for testing the codegra.de website. Testing
is done for every merge to stable, which is seen as a release. It is highly
recommended that you sign all your commits using you GPG key.

## How to test
Testing is done for the four major browsers:

- Google Chrome
- Firefox
- Safari
- Edge

All testing should be done against the latest stable version at the moment of
testing. To start testing first create a new directory with the codename of the
new release you are testing. So if we are creating a new merge to stable that
with version number `x.y.z` and release name `$a` create a directory `tests_$a`
and add the empty file `.gitkeep` in it. Please note that the release version
should **not** be in the directory. Directly commit this directory with the
message `[TESTS] Codename - OPEN` where codename is the codename of the release.

Now create a test file, copied from `tests.md` with the name `x.y.z_browser.md`
where `x.y.z` is the version number and `browser` is the browser you are
testing.

In this file fill in all the information under the `Information` header and
start performing all listed tests. For every step that succeeds (or does not
fail) mark the checkbox with a `x`. If a step of a test fails take a useful
screenshot and stop performing the test. Now directly add the test to the errors
lists with its index, the url of the screenshot (do not save the screenshot in
the git repo) and describe exactly what you were doing and what went wrong.
After you did this you should reset the database and continue with the next
tests. If you have generic comments at any time during testing add them under
the `Comments` header in the test file. If all tests succeed you should fill in
the information under the `Sign off` header indicating that you signed these
tests off.

After you are done with all the tests you should commit the new test file to the
master branch of this repository. The message should be `[TEST] Codename -
Browser - State` where `Codename` is the code name of the version you are
testing, browser is the version you tested with and `State` is either `PASS` or
`FAIL` depending on if the test failed. As you should only commit completed test
files you should never edit a test file in a commit.

If all required browsers have passed all tests for the newest version (this
means that all browsers have passed for the same version!) you should create a
file `SIGN-OFF` containing the following contents:
```markdown
Name
Date
```
Where the `Name` is your name and `Date` is the date you signed this version
off. You should commit this file in a single commit with the message `[TESTS]
Codename - DONE` where `Codename` is the codename of the release. This file may
not be edited, but can (and should) be deleted if a newer version will the
version for this release (so if the codegra.de master is updated). The message
should be `[TESTS] Codename - REOPEN`.
