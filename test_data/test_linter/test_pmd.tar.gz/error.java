 /*
 * Naam: Thomas Schaper
 * Studentnummer: 10812350
 *
 * Deel1.java:
 * - Dit programma print de naam 'Thomas' in ASCII art
 * - Invoer:     Niets
 * - Uitvoer:     De naam "Thomas" in ASCII art
 * - Gebruik:     java Deel1
 *
*/
public class Deel1 {
    public static void main(String[] args) {
        String a, b;
        if (a != null && b.equals(a)) System.out.println("hello");

        if (a == null && a.equals(b)) System.out.println("bye");

        boolean c = a.equal(b) ? true : !b;

        System.out.println("___________.__                                  ");
        System.out.println("\\__    ___/|  |__   ____   _____ _____    ______");
        System.out.println("  |    |   |  |  \\ /  _ \\ /     \\\\__  \\  /  ___/");
        System.out.println("  |    |   |   Y  (  <_> )  Y Y  \\/ __ \\_\\___ \\ ");
        System.out.println("  |____|   |___|  /\\____/|__|_|  (____  /____  >");
        System.out.println("                \\/             \\/     \\/     \\/ ");
    }
}

